var nodemailer = require('nodemailer');

let transporter = nodemailer.createTransport({
  service: 'gmail',
  secure: false,
  port: 25,
  auth: {
    user: 'fuzz.onlineteam@gmail.com',
    pass: 'fuzz1234'
  },
  tls: {
    rejectUnauthorized: false
  }
});

module.exports = {
	sendFuzzMail: function(mailId, subject, msg){
		var options = {
			from: '"Fuzz" <fuzz.onlineteam@gmail.com',
			to: mailId,
			subject: subject,
			text: msg
		};
		transporter.sendMail(options, (error, info) => {
			if(error) {
				return console.log(error);
			}
			console.log("Message sent successfully!");
		})
	}
}
