var AWS = require("aws-sdk");
AWS.config.update({
    region: "ap-south-1",
    endpoint: "https://dynamodb.ap-south-1.amazonaws.com"
});
var docClient = new AWS.DynamoDB.DocumentClient();


module.exports = {
  userAuthentication: function(request, response, callback){
    var data = {
      auth: false,
    }
    if(!request.cookies.pid){
      callback(request, response, data);
    } else {
      var params = {
        TableName: "Users",
        Key:{
          "uid": decodeURIComponent(request.cookies.uid),
        },
        ProjectionExpression: "verified, first_name, favourites, addresses, #order, mybag, mybag_items, sessions, defaults, dob, email",
        ExpressionAttributeNames: {
          "#order": "orders"
        }
      }
      docClient.get(params, function(err, result){
        if(err){
          console.log("Unable to scan the table. Error JSON:", JSON.stringify(err, null, 2));
        } else {
          if(result.Item){
            data.auth = true;
            data.user_details = result.Item;
          } else {
            response.clearCookie('uid');
            response.clearCookie('pid');
            data.auth = false;
          }
          data.uid = request.cookies.uid;
          callback(request, response, data);
        }
      });
    }
  }
}
