function showError(msg){
	$(".pop-error").html(msg);
	$(".pop-error").fadeIn("fast");
	var error_timeout = setTimeout(function(){
		$(".pop-error").fadeOut("fast");
	},10000)
}
function changeUrl(stateObj, title, url){
	history.pushState(stateObj, title, url);
}
$(".pop-error").click(function(){
	$(".pop-error").fadeOut("fast");
})

$(document).click(function(eve){
	$(".theme-box").hide();
})

$(".toggle-theme").hover(function(eve){
	$(".theme-box").css({"display":"block","left": $(this).offset().left-30, "top": $(this).offset().top + 28});
	if(eve.type == "mouseleave"){
		$(".theme-box").hover(function(eve){
			if(eve.type == "mouseleave"){
				$(this).hide();
			} else {
				$(this).show();
			}
		})
		$(".theme-box").hide();
	}
})
$(".theme-box").click(function(eve){
	eve.stopPropagation();
})

$(window).scroll(function (event) {
    var scroll = $(window).scrollTop();
    if(scroll > 25){
    	$(".navbar").css({"background-color":"white","border-color":"#0097D3"});
    	$(".navbar-brand").css({"color":"#0097D3"});
    	$(".nav-user-button, .nav-icon").css({"color":"#0097D3","border-color":"#0097D3"});
    	$(".nav-user-button, .nav-icon").hover(function(e) { 
		    $(this).css({
	   			"background-color":(e.type === "mouseenter"?"#0097D3":"transparent"),
				"color":(e.type === "mouseenter"?"white":"#0097D3")
			}) 
		})
		$(".search-box").css("border-color","#0097D3");
    	$(".nav-link").css({"color":"#0097D3"});
    } else {
    	$(".navbar").css({"background-color":"#0097D3","border-color":"white"});
    	$(".navbar-brand").css({"color": "white"});
    	$(".nav-user-button, .nav-icon").css({"color": "white", "border-color": "white"});
    	$(".nav-user-button, .nav-icon").hover(function(e) { 
		    $(this).css({
	   			"background-color":(e.type === "mouseenter"?"white":"transparent"),
				"color":(e.type === "mouseenter"?"#0097D3":"white")
			}) 
		})
		$(".search-box").css("border-color","white");
    	$(".nav-link").css({"color": "white"});
    }
});
var color_count = 0;
function rainbow(){
	var colors = ['violet', 'indigo', 'blue', 'green', 'yellow', 'orange', 'red'];
	color_count += 1;
	setTimeout(function(){
		$(".multi").css({"background-color":colors[color_count%7]});
		rainbow();
	},1000)
}
rainbow();
$(".theme-sel").click(function(){
	$(".loading-bar").show();
	var q = $(this).attr("value");
	console.log(q);
	window.location = window.location.origin + "/filter?t=theme&q=" + q;
})
$(".get-otp").click(function(){
	$("#otp").focus();
	$.ajax({
		type: 'post',
		url: '/action/getotpsign',
		data: {
			number: $("#number").val(),
		},
		success: function(data){
			console.log(data);
		},
		error: function(){
			console.log("Error Occured!");
		}
	})
})
$(".num-input").keypress(function(eve){
	if(eve.charCode < 48 || eve.charCode > 57){
		eve.preventDefault();
	}
})
$(".register-me").click(function(){
	$(".loading-bar").show();
	$.ajax({
		type:'post',
		url: '/action/verifyandcreate',
		data: {
			contact_number: $("#number").val(),
			first_name: $("input[name=firstName]").val(),
			otp: $("input[name=otp]").val(),
			password: $("input[name=password]").val(),
		},
		success: function(data){
			if(data.userExist){
				showError("User with that Mobile Number already Exist.");
			}
			else if(data.created == 1){
				window.location = window.location
			}
			else if(data.created == -1){
				showError("Error Occured in performing your request!");
			}
			else{
				showError("Invalid OTP, Please Try Again.")
			}
			$(".loading-bar").hide();
		},
		error: function(){
			showError("Check Your Internet and Try Again.")
			$(".loading-bar").hide();
		}
	})
})
$("#sign_in").on("submit", function(eve){
	eve.preventDefault();
	var number = $("#contact_number").val();
	$.ajax({
		type: 'post',
		url: '/action/signinauth',
		data: {
			contact_number: $("#contact_number").val(),
			password: $("#password_sign").val()
		},
		success: function(data){
			if(data.auth){
				window.location = window.location;
			} else {
				showError("Invalid Username or Password !");
			}
			
		},
		error: function(){
			showError("Error Occured!")
		}
	})
})
$("#search").on("submit", function(eve){
	eve.preventDefault();
	$.ajax({
		type: "post",
		url: "/search",
		data: {
			q: $("input[name=q]").val()
		},
		success: function(data){
			if(data.status){
				window.location = window.location.origin
			} else {
				if($(".on-the-fly-product-div")[0]){
					$(".on-the-fly-product-div").html(data);
				} else {
					window.location = window.location.origin + "/search?q=" + $("input[name=q]").val()
				}
				state = {
					"name": "Search"
				}
				changeUrl(state, $("input[name=q]").val() + " | Fuzz Search", "/search?q=" + $("input[name=q]").val())
			}
		}
	})
})
$(".draw-close").click(function(){
	$(".draw-box").hide();
})

$("#no-account").click(function(){
	$(".sign-div").hide();
	$(".register-div").show();
})
$('#have-account').click(function(){
	$(".sign-div").show();
	$(".register-div").hide();
})
function showReg(){
	$(".backdrop").show();
	$(".popup-div").show();
}
$(".register-sign-in").click(function(){
	showReg();
})

$(".backdrop").click(function(){
	$(".popup-div").hide();
	$(this).hide();
})