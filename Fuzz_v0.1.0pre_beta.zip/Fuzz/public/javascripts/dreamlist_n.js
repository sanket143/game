var size_selected = false;
var user_selected_size;
$(document).ready(function(){
	$(".size-button").on("click",function(){
		$(".size-button").css({"background-color":"white", "color":"#b96f6f"});
		$(this).css({"background-color":"#ff9e9e","color":"white"});
		size_selected = true;
		user_selected_size = $(this).text();
		console.log(user_selected_size)
	})
	
	$(".size-button").mouseenter(function(){
		if(!size_selected){
			$(this).css({"background-color":"#ff9e9e","color":"white"});
		}
	})
	$(".size-button").mouseleave(function(){
		if(!size_selected){
			$(this).css({"background-color":"white", "color":"#b96f6f"});
		}
	})
})
$(".product-view").click(function(){
	var product_slug = $(this).attr("value");
	window.location = window.location.origin + "/product_details/" + product_slug;
})
$(".remove-item").click(function(){
	$(".loading-bar").show();
	$.ajax({
		type:'post',
		url: '/action/removefromlist',
		data: {
			product_slug: $(this).attr("value")
		},
		success: function(data){
			$('.loading-bar').hide();
			showError("Successfully removed from List")
			window.location = window.location;
		},
		error: function(){
			$('.loading-bar').hide();
			showError("Error Occured in moving to Bag!")
		}
	})
})
