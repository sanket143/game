var def_email;
var def_verified;
$(document).ready(function(){
	def_email = $("#email").val();
	if($(".profile-status").text() == "verified"){
		def_verified = true;
	} else {
		def_verified = false;
	}
})
$(".profile-label").hover(function(eve){
	console.log("#1")
		$(this).children("i").css({
			"color":(eve.type == "mouseenter" ? "black" : "transparent"),
		});
})
$(document).on("click", ".edit-stuff", function(){
	var value = $(this).attr("value");
	if(value == "birthdate"){
		$(".backdrop").show();
		$(".div-popper").show();
		$(".birthday-editor").show();
	} else if (value == "emailaddress"){
		$(".backdrop").show();
		$(".div-popper").show();
		$(".email-editor").show();
	}
})
$(document).on("click", ".backdrop", function(){
	$(".backdrop").hide();
	$(".div-popper").hide();
	$(".div-popper").children("div").hide();
})
function setEmail(){
	var email = $("#email").val();
	if(def_verified && email == def_email){
		showError(email + " is already verified!");
	} else {
		$.ajax({
			type: "post",
			url: "/action/setemail",
			data: {
				email: email
			},
			success:function(data){
				if(data.status){
					window.location = window.location;
				} else {
					showError("Error Occured in updating Email!")
				}
			},
			error: function(){
				showError("Please Check Your Internet Connection!")
			}
		})
	}
	
}
$(document).on("keypress", "#email", function(eve){
	if(eve.charCode == 13){
		setEmail();
	}
})
$(document).on("click", "#set_email", function(){
	setEmail();
})