$(".toggle-style").click(function(){
	$(".style").slideToggle("fast");
})
$(".toggle-neck").click(function(){
	$(".neck").slideToggle("fast");
})
$(".toggle-price-limiter").click(function(){
	$(".price-limiter").slideToggle("fast");
})
$(".toggle-wear").click(function(){
	$(".wear").slideToggle("fast");
})
$(".toggle-colors").click(function(){
	$(".colors").slideToggle("fast");
})




$(".menu-items").click(function(){
	if(!$(this).hasClass("price-limiter")){
		$(".loading-bar").show();
		var q = $(this).attr("value");
		var t = $(this).parent().attr("value");
		$.ajax({
			type:"post",
			url:'/filter',
			data:{
				q: q,
				t: t,
				json: true
			},
			success: function(data){
				$(".on-the-fly-product-div").html(data);
				$(".loading-bar").hide();
				var state = {
					"name": t
				}
				changeUrl(state, "Filter by " + t + " | Fuzz", "/filter?q=" + q + "&t=" + t);
			},
			error: function(){
				$(".loading-bar").hide();
				showError("Error Occured !");
			}
		})
	}
})




$("#price_range").change(function(){
	$(".loading-bar").show();
	var price_value = $(this).val();
	$.ajax({
		type: 'post',
		url: '/filter/price',
		data: {
			lim: price_value,
			json: true
		},
		success: function(data) {
			$(".on-the-fly-product-div").html(data);
			$(".loading-bar").hide();
			var state = {
				"name": "price"
			}
			changeUrl(state, "Filter by Price | Fuzz", "/filter/price?lim=" + price_value);
		},
		error: function(){
			$(".loading-bar").hide();
		}
	})
});
$(document).on("click", ".show-product", function(){
	window.location = window.location.origin + "/product_details/" + $(this).attr("value")
})
$(document).ready(function(){
	var slider = document.getElementById("price_range");
	var price_value = document.getElementById("price_value");
	console.log(slider.value)
	price_value.innerHTML = slider.value;
	
	slider.oninput = function(){
		price_value.innerHTML = this.value;
	}	
})



