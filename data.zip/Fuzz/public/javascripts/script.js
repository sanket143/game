/* FUNCTION */
function showError(msg){
  $(".pop-error").html(msg);
  $(".pop-error").fadeIn("fast");
  var error_timeout = setTimeout(function(){
    $(".pop-error").fadeOut("fast");
  },10000)
}
function changeUrl(stateObj, title, url){
  history.pushState(stateObj, title, url);
}
var color_count = 0;
function rainbow(){
  var colors = ['violet', 'indigo', 'blue', 'green', 'yellow', 'orange', 'red'];
  color_count += 1;
  setTimeout(function(){
    $(".multi").css({"background-color":colors[color_count%7]});
    rainbow();
  },1000)
}
rainbow();
function showReg(){
  reset()
  $(".backdrop").show();
  $(".popup-div").show();
}
function reset(){
  $(".backdrop").hide();
  $(".mobile-setting-options, .mobile-user-options").hide();
  $(".mobile-filter-settings, .mobile-user-settings").css({
    "width": "0%"
  })
  $(".mobile-filter-opener").css({
    "left": "0%"
  });
  $(".mobile-setting-opener").css({
    "right": "0%"
  })
  $(".popup-div").hide();
  $(".mobile-setting-options").hide();
}

// NUMBERS ONLY
function numOnly(element){
  var value = element.val();
  element.val(value.replace(/[^0-9]+/g, ""));
}

/* JQuery Events */
$(document).ready(function(){
  var marginVal = $(".navbar").outerHeight() + "px";
  $(".neutralize").css({
    "height": marginVal,
    "padding-top": ($(".navbar").outerHeight() - 32).toString() + "px",
  })
  $(".top-neutralize").css({
    "margin-top":$(".neutralize").outerHeight(),
    "height": 0,
  });
  var setting_css = {
    "height": window.outerHeight - $(".navbar").outerHeight()*2,
    "margin-left": $(".mobile-setting-options").outerWidth()/2*(-1),
    "margin-top": $(".navbar").outerHeight() + 1,
  }
  $(".mobile-setting-options").css(setting_css);
})

$(".pop-error").click(function(){
  $(".pop-error").fadeOut("fast");
})

$(document).click(function(eve){
  $(".theme-box").hide();
})

$(".toggle-theme").hover(function(eve){
  $(".theme-box").css({"display":"block","left": $(this).offset().left-30, "top": $(this).offset().top + 28});
  if(eve.type == "mouseleave"){
    $(".theme-box").hover(function(eve){
      if(eve.type == "mouseleave"){
        $(this).hide();
      } else {
        $(this).show();
      }
    })
    $(".theme-box").hide();
  }
})


$(".theme-box").click(function(eve){
  eve.stopPropagation();
})

$(window).scroll(function (event) {
    var scroll = $(window).scrollTop();
    if(scroll > 25){
      $(".navbar").css({"background-color":"white","border-color":"#0097D3"});
      $(".navbar-brand").css({"color":"#0097D3"});
      $(".nav-user-button, .nav-icon").css({"color":"#0097D3","border-color":"#0097D3"});
      $(".nav-user-button, .nav-icon").hover(function(e) { 
      $(this).css({
        "background-color":(e.type === "mouseenter"?"#0097D3":"transparent"),
        "color":(e.type === "mouseenter"?"white":"#0097D3")
      }) 
    })
    $(".search-box").css("border-color","#0097D3");
      $(".nav-link").css({"color":"#0097D3"});
    } else {
      $(".navbar").css({"background-color":"#0097D3","border-color":"white"});
      $(".navbar-brand").css({"color": "white"});
      $(".nav-user-button, .nav-icon").css({"color": "white", "border-color": "white"});
      $(".nav-user-button, .nav-icon").hover(function(e) { 
      $(this).css({
        "background-color":(e.type === "mouseenter"?"white":"transparent"),
        "color":(e.type === "mouseenter"?"#0097D3":"white")
      }) 
    })
    $(".search-box").css("border-color","white");
      $(".nav-link").css({"color": "white"});
    }
});





$(".get-otp").click(function(){
  $("#otp").focus();
  $.ajax({
    type: 'post',
    url: '/action/getotpsign',
    data: {
      number: $("#number").val(),
    },
    success: function(data){
      console.log(data);
    },
    error: function(){
      console.log("Error Occured!");
    }
  })
})
$(".num-input").keypress(function(eve){
  if(eve.charCode < 48 || eve.charCode > 57){
    eve.preventDefault();
  }
});
$(".num-input").keyup(function(eve){
  numOnly($(this));
})
$(".register-me").click(function(){
  $(".loading-bar").show();
  $.ajax({
    type:'post',
    url: '/action/verifyandcreate',
    data: {
      contact_number: $("#number").val(),
      first_name: $("input[name=firstName]").val(),
      otp: $("input[name=otp]").val(),
      password: $("input[name=password]").val(),
    },
    success: function(data){
      if(data.userExist){
        showError("User with that Mobile Number already Exist.");
      }
      else if(data.created == 1){
        window.location = window.location
      }
      else if(data.created == -1){
        showError("Error Occured in performing your request!");
      }
      else{
        showError("Invalid OTP, Please Try Again.")
      }
      $(".loading-bar").hide();
    },
    error: function(){
      showError("Check Your Internet and Try Again.")
      $(".loading-bar").hide();
    }
  })
})
$("#sign_in").on("submit", function(eve){
  eve.preventDefault();
  var number = $("#contact_number").val();
  $.ajax({
    type: 'post',
    url: '/action/signinauth',
    data: {
      contact_number: $("#contact_number").val(),
      password: $("#password_sign").val()
    },
    success: function(data){
      if(data.auth){
        window.location = window.location;
      } else {
        showError("Invalid Username or Password !");
      }
      
    },
    error: function(){
      showError("Error Occured!")
    }
  })
})
$("#search").on("submit", function(eve){
  eve.preventDefault();
  $.ajax({
    type: "post",
    url: "/search",
    data: {
      q: $("input[name=q]").val()
    },
    success: function(data){
      if(data.status){
        window.location = window.location.origin
      } else {
        if($(".on-the-fly-product-div")[0]){
          if(data){
            $(".on-the-fly-product-div").html(data);
          } else {
            showError("Sorry no result found, Try Something Else!");
          }
          
        } else {
          window.location = window.location.origin + "/search?q=" + $("input[name=q]").val()
        }
        state = {
          "name": "Search"
        }
        changeUrl(state, $("input[name=q]").val() + " | Fuzz Search", "/search?q=" + $("input[name=q]").val())
      }
    }
  })
})
$(".draw-close").click(function(){
  $(".draw-box").hide();
})

$("#no-account").click(function(){
  $(".sign-div").hide();
  $(".register-div").show();
})
$('#have-account').click(function(){
  $(".sign-div").show();
  $(".register-div").hide();
})

$(".register-sign-in").click(function(eve){
  showReg();
})
$(".backdrop").click(function(){
  reset();
})



/* MOBILE VIEWS */

if(window.outerWidth <= 700){
  var on_the_fly_product_div = document.getElementsByClassName("on-the-fly-product-div")[0];
  if(on_the_fly_product_div){
    on_the_fly_product_div.className = "on-the-fly-product-div";
  }
  
  var popup_div = document.getElementsByClassName("popup-div")[0];
  if(popup_div){
    popup_div.style.width = "100%";
    popup_width = parseInt($(".popup-div").css("width").replace(/[^\d.]/g, '' ));
    popup_div.style.width = (popup_width - 8) + "px";
    popup_div.style["margin-left"] = ((-1) * (popup_width - 8)/2) + "px";
  }

  $(".mobile-setting-opener, .mobile-filter-opener").css({"visibility": "hidden"});
  $(document).ready(function(){
    $(".mobile-setting-opener, .mobile-filter-opener").css({
      "top": "50%",
      "margin-top": $(".mobile-setting-opener").offsetHeight/2*(-1),
      "visibility": "visible",
    })
  })

  /* OPENERS CODE */

  $(".mobile-filter-opener").click(function(){
    var NULL_POINT = ["1px", "0%"];
    if(NULL_POINT.indexOf($(".mobile-filter-settings").css("width"))){
      reset();
    } else {
      $(".backdrop").show();
      $(".mobile-filter-settings").css({
        "width": "55%"
      })
      $(this).css({
        "left": "55%"   
      })    
    }
  })
  $(".mobile-setting-opener").click(function(){
    var NULL_POINT = ["1px", "0%"];
    if(NULL_POINT.indexOf($(".mobile-user-settings").css("width"))){
      reset();
    } else {
      $(".backdrop").show();
      $(".mobile-user-settings").css({
        "width": "55%"
      });
      $(this).css({
        "right": "55%"
      })
    }
  })
  $(".mobile-filter-setting").click(function(){
    reset();
    var filter = $(this).attr("value");
    var element = ".mobile-" + filter + "-box";
    $(".mobile-setting-option-box").hide();
    $(".backdrop").show();
    $(element).show();
    $(".mobile-setting-options").show();
  })
  // When User click the filter option
  $(".option-sel").click(function(eve){
    $(".loading-bar").show();
    var query = $(this).attr("value");
    var tag = $(this).attr("tag");
    $.ajax({
      type:"post",
      url:"/filter",
      data: {
        "t": tag,
        "q": query
      },
      success: function(data){
        $(".on-the-fly-product-div").html(data);
        $(".loading-bar").hide();
        var state = {
	  "name": $(this).attr("tag")
        }

        changeUrl(state, "Filter by " + tag + " | Fuzz", "/filter?q=" + query + "&t=" + tag);
      },
      error: function(){
        $(".loading-bar").hide();
        showError("Error Occured !");
      }
    })
    reset();
  })  
  $(".mobile-user-option").click(function(){
    reset();
    var filter = $(this).attr("value");
    var element = ".mobile-" + filter + "-box";
    $(".mobile-filter-options").children("div").css({
      "display": "none"
    })
    $("."+filter+"-sel").click(function(){
      $(".mobile-filter-options").hide();
      $(".backdrop").hide();
      $(".loading-bar").show();
          })
    $(element).css({
      "display":"block"
    })
    $(".mobile-"+filter+"-sel-div").css({
      "padding":"10px",
      "border-bottom": "1px solid #b4e7fd"
    })
    $(".mobile-"+filter+"-sel-div").children("span").css({
      "color": "#0097d3",
      "margin": "10px",
      "font-weight": "bold",
      "cursor": "pointer"
    })
    $(".mobile-user-options").css({"width": "0"});
    $(".mobile-filter-options").fadeIn("fast");
    $('.backdrop').show();
    $(element).parent().css({
         })
    $(element).parent().fadeIn("fast");
  })  
  $("body").swipe({
    swipeRight:function(event, direction, distance) {
      if(distance >= 100){
        reset();
        $(".mobile-filter-settings").css({"width": "55%"});
        $(".mobile-filter-opener").css({"left": "55%"});
        $(".backdrop").show();
      }
    },
    swipeLeft:function(event, direction, distance) {
      if(distance >= 100){
        reset();
        $(".mobile-user-settings").css({"width": "55%"});
        $(".mobile-user-opener").css({"right": "55%"});
        $(".backdrop").show();
      }
    }
  })
} else {
  $(".theme-sel").click(function(){
    $(".loading-bar").show();
    var q = $(this).attr("value");
    console.log(q);
    window.location = window.location.origin + "/filter?t=theme&q=" + q;
  })
}
