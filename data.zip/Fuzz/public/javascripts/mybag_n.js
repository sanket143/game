function continue_func(){
  $(".backdrop").fadeIn("fast");
  $(".div-get-otp").fadeIn("fast");
  
}

function get_otp_check(){
  $(".div-get-otp").fadeOut("fast");
  $(".div-check-out").fadeIn("fast");
}
$(".backdrop").click(function(){
  $(".div-get-otp").fadeOut("fast");
  $(".backdrop").fadeOut("fast");
  $(".div-check-out").fadeOut("fast");
})
$(".delete").click(function(){
  console.log($(this).children("input[name=product_slug]").val());
})

$(".remove-link").click(function(){
  var product_slug = $(this).attr("value");
  $("loading-bar").show();
  $.ajax({
    url: '/action/removeitem',
    type: 'post',
    data:{
      "product_slug": product_slug
    },
    success: function(data){
      $("loading-bar").hide();
      window.location = window.location;
    },
    error: function(){
      $("loading-bar").hide();
    }
  })
})
