$(".menu-item").click(function(){
  var option = $(this).attr("value");
  $(".loading-bar").show();
  $(".menu-item").css({
    "font-weight": 100,
    "border-left": "1px solid #e1e4e8"
  })
  $(this).css({
    "font-weight": "bold",
    "border-left": "1px solid #0097D3"
  })
  $.ajax({
    type: "post",
    url: "/users/settings/",
    data: {
      option: option
    },
    success: function(data){
      if(data.status === false){
        showError("Error Occured.");
      } else {
        $(".body-content").html(data);
        var state = {
          "name": option
        }
        option[0] = option[0].toUpperCase();
        changeUrl(state, option, "/users/settings/" + option)
      }
      $(".loading-bar").hide();
    },
    error: function(){
      showError("Check your Internet Connection and Try Again!");
      $(".loading-bar").hide();
    }
  })
})
$(".mobile-menu-item").click(function(){
  $(".loading-bar").show();
  var options = document.getElementsByClassName("mobile-menu-item");
  var option = $(this).attr("value");
  // TOGGLES THE CLASS NAME
  for(i = 0; i < options.length; i++){
    options[i].classList.remove("mobile-selected");
  }
  $(this).addClass("mobile-selected");

  $.ajax({
    type: "post",
    url: "/users/settings/",
    data: {
      option: option
    },
    success: function(data){
      if(data.status === false){
        showError("Error Occured.");
      } else {
        $(".body-content").html(data);
        var state = {
          "name": option
        }
        option[0] = option[0].toUpperCase();
        changeUrl(state, option, "/users/settings/" + option)
      }
      $(".loading-bar").hide();
    },
    error: function(){
      showError("Check your Internet Connection and Try Again!");
      $(".loading-bar").hide();
    }
  })

});
