$(document).ready(function(){
  var data = {};
  $(document).on("click", ".address-save", function(){
    data.address_name = $("input[name=address_name]").val();
    data.country = $("select[name=country]").val();
    data.full_name = $("input[name=full_name]").val();
    data.mobile_number = $("input[name=mobile_number]").val();
    data.pincode = $("input[name=pincode]").val();
    data.first_address = $("input[name=first_address]").val();
    data.second_address = $("input[name=second_address]").val();
    data.landmark = $("input[name=landmark]").val();
    data.city = $("input[name=city]").val();
    data.state = $("select[name=state]").val();
    if(Object.values(data).filter(Boolean).length != 10){
      console.log(data);
      alert("Please fill all values !");
    } else {
      $.ajax({
        type: 'post',
        url: '/action/addaddress',
        data: data,
        success: function(data){
          if(data.status){
            window.location = window.location;
          } else {
            showError("Address with that name Already Exist !")
          }
        },
        error: function(){
          console.log("Error Occured!");
        }
      })
    }
  })
})
$(document).on("click", ".remove-address", function(){
  var address = $(this).attr("value");
  $.ajax({
    type: "post",
    url: "/action/removeaddress",
    data: {
      add_name: address,
    },
    success: function(data){
      showError("Successfully Removed !");
      window.location = window.location
    },
    error: function(){
      showError("Error Occured");
    }
  })
})
$(document).on("click", ".default-address", function(){
  var address = $(this).attr("value");
  $.ajax({
    type:"post",
    url: "/action/makeaddressdefault",
    data: {
      add_name: address
    },
    success: function(data){
      window.location = window.location;
    },
    error: function(){
      console.log("Error Occured");
    }
  })
})
$(document).on("click", ".add-new-address", function(){
  $(".addresses").hide();
  $(".add-address").slideDown("fast")
})

$(document).on("click", ".address-cancel", function(){
  $(".addresses").show();
  $(".add-address").hide();
})