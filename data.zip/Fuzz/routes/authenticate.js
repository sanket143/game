var express = require('express');
var router = express.Router();

var AWS = require("aws-sdk");
AWS.config.update({
  region: "ap-south-1",
  endpoint: "https://dynamodb.ap-south-1.amazonaws.com"
});
var docClient = new AWS.DynamoDB.DocumentClient();


router.get('/', function(req, res, next){
  var params = {
    TableName: "Users",
    Key: {
      "uid": req.query.uid,
    },
    UpdateExpression: "SET #ver =:verify, #token = :null",
    ConditionExpression: "#token = :token",
    ExpressionAttributeValues: {
      ":verify": true,
      ":token": req.query.token,
      ":null": 0,
    },
    ExpressionAttributeNames: {
      "#ver": "verified",
      "#token": "token",
    },
    ReturnValues: "UPDATED_OLD"
  }
  docClient.update(params, function(err, data){
    var home = "<html><script>" +
    "window.location = window.location.origin"+
    "</script></html>";
    if(err){
      console.log(err);

      res.send("Invalid Token" + home);
    } else {
      console.log(data);
      res.send("Verified Successfully!" + home);
    }
  })
})

module.exports = router;