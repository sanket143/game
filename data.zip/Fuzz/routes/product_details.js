var express = require('express');
var router = express.Router();
var userAuthentication = require('./modules/UserAuth').userAuthentication;


var AWS = require("aws-sdk");
AWS.config.update({
  region: "ap-south-1",
  endpoint: "https://dynamodb.ap-south-1.amazonaws.com"
});
var docClient = new AWS.DynamoDB.DocumentClient();


router.get("/:prod_slug", function(req, res, next){
  var data = {};
  userAuthentication(req, res, function(req, res, data){
    var product_slug = req.params.prod_slug;
    var params = {
      TableName: "Product-Details",
      Key: {
        "product_slug": product_slug
      },
      ProjectionExpression: "product_title, product_slug, img_src, price_tag, keywords, discount, favourites_of, available_sizes"
    }
    docClient.get(params, function(err, result){
      if(err){
        console.log("JSON Error:", err);
        data.available = false;
      } else {
        data.available = false;
        if(result.Item){
          data.available = true;
          data.product_details = result.Item;
        }
        var num_product_in_bag = 0;
        if(data.user_details){
          for(i = 0; i < data.user_details.mybag.length; i++){
            if(data.user_details.mybag[i] == product_slug){
              num_product_in_bag += parseInt(data.user_details.mybag_items[i].quantity);
            }
          }
        }
        data.num_product_in_bag = num_product_in_bag;
        res.render('product_details', data);
      }
    })
  })
  
})

module.exports = router;
