var express = require('express');
var router = express.Router();
var assert = require("assert");
var metaphone = require("metaphone");
var userAuthentication = require('./modules/UserAuth').userAuthentication;

var AWS = require("aws-sdk");
AWS.config.update({
  region: "ap-south-1",
  endpoint: "https://dynamodb.ap-south-1.amazonaws.com"
});
var docClient = new AWS.DynamoDB.DocumentClient();


router.get("/", function(req, res, next) {
  if(!req.query.q){
    res.redirect("/")
  } else {
    userAuthentication(req, res, function(req, res, data){
      keywords = req.query.q.toLowerCase().split(" ").filter(Boolean);

      var params = {
        TableName: "Product-Details",
        ProjectionExpression: "product_title, product_slug, img_src, price_tag, keywords, discount"
      }
      var products = [];
      docClient.scan(params, function(err, result){
        if(result.Items){
          result.Items.forEach(function(product_details){
            keywords.forEach(function(keyword){
              if(product_details.keywords.map(metaphone).indexOf(metaphone(keyword)) != -1){
                products.push(product_details);
              }
            })
          })
          data.product_details = products;
          data.search_key = req.query.q;
          res.render("index", data);  
        }
      })
    })
  }
})


router.post("/", function(req, res, next){
	var status = false;
	if(!req.body.q){
		res.send({
			status: false,
		})
	} else {
		userAuthentication(req, res, function(req, res, data){
      keywords = req.body.q.toLowerCase().split(" ").filter(Boolean);

      var params = {
        TableName: "Product-Details",
        ProjectionExpression: "product_title, product_slug, img_src, price_tag, keywords, discount"
      }
      var products = [];
      docClient.scan(params, function(err, result){
        if(result.Items){
          result.Items.forEach(function(product_details){
            keywords.forEach(function(keyword){
              if(product_details.keywords.map(metaphone).indexOf(metaphone(keyword)) != -1){
                products.push(product_details);
              }
            })
          })
          data.product_details = products;
          data.status = true;
          res.render("./templates/show_products", data);  
        }
        
      })
    })
	}
})
module.exports = router;