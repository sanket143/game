var express = require('express');
var router = express.Router();
var assert = require("assert");
var bcrypt = require('bcrypt');
var userAuthentication = require('./modules/UserAuth').userAuthentication;

const SendOtp = require('sendotp');


var AWS = require("aws-sdk");
AWS.config.update({
  region: "ap-south-1",
  endpoint: "https://dynamodb.ap-south-1.amazonaws.com"
});
var docClient = new AWS.DynamoDB.DocumentClient();

// Generates a Token
function tokenGenerator(len) {
  charSet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var token = '';
  for (var i = 0; i < len; i++) {
    var randomPoz = Math.floor(Math.random() * charSet.length);
    token += charSet.substring(randomPoz,randomPoz+1);
  }
  return token;
}
function sendOTP(number, OTP){
  
  const sendOtp = new SendOtp("215985Aycje66oc15afdfd00", "Hi Fuzzy!, {{otp}} is your Fuzz verification code. DO NOT SHARE this OTP.");
  sendOtp.send(number, "FUZZCO", OTP, function(error, data, response) {
    console.log(data);
  })
}

function verifyOTP(number, OTP){
  const sendOtp = new SendOtp('215985Aycje66oc15afdfd00');
  sendOtp.verify(number, OTP, function (error, data, response) {
    if(error){
      console.log(error);
    } else {
      console.log(data.type);
    }
  });
}


router.get('/', function(req, res, next) {
  
  userAuthentication(req, res, function(req, res, data){
    var params = {
      TableName: "Product-Details",
      ProjectionExpression: "product_title, product_slug, img_src, price_tag, keywords, discount"
    }
    docClient.scan(params, function(err, result){
      if(err){
        console.log("Unable to scan the table. Error JSON:", JSON.stringify(err, null, 2));
      } else {
        data.product_details = result.Items;
        res.render("index", data);
      }
    })
  })
});


router.get("/logout", function(req, res, next){
  res.clearCookie("uid");
  res.clearCookie("pid");
  res.redirect("/");
})
module.exports = router;
