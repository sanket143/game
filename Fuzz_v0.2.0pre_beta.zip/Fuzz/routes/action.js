var express = require('express');
var router = express.Router();
var mailer = require('./modules/mailer');
var SendOtp = require('sendotp');
var bcrypt = require('bcrypt');

var salt = "$2b$10$4hArzkKNl48Kn27Z2YbXru";

var AWS = require("aws-sdk");
AWS.config.update({
  region: "ap-south-1",
  endpoint: "https://dynamodb.ap-south-1.amazonaws.com"
});
var docClient = new AWS.DynamoDB.DocumentClient();


function sendOTP(number, OTP, msg){
  
  const sendOtp = new SendOtp("215985Aycje66oc15afdfd00", msg);
  sendOtp.send(number, "FUZZCO", OTP, function(error, data, response) {
    console.log(data);
  })
}

function verifyOTP(number, OTP, callback){
  const sendOtp = new SendOtp('215985Aycje66oc15afdfd00');
  sendOtp.verify(number, OTP, function (error, data, response) {
    console.log(data);
    callback(error, data);
  })
}

function tokenGenerator(len) {
  charSet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var token = '';
  for (var i = 0; i < len; i++) {
    var randomPoz = Math.floor(Math.random() * charSet.length);
    token += charSet.substring(randomPoz,randomPoz+1);
  }
  return token;
}

function createUser(credentials){
  var table = "Users";
  var params = {
    TableName:table,
    Item:credentials,
  }
  docClient.put(params, function(err, result) {
    if (err) {
      console.error("Unable to add item. Error JSON:", JSON.stringify(err, null, 2));
    }
  });
}

/*
* Get OTP Sign

* Actions
* Verify OTP
* Remove Item
* Get OTP
* Add Address
* Check Out
* Add Favourite
* Add to my Bag
*/
router.post("/getotpbag", function(req, res, next){
  var number = req.body.number;
  var OTP = parseInt(Math.random()*100000).toString();
  sendOTP(number, OTP, "Hi Fuzzy!, {{otp}} is your OTP to confirm your Order on Fuzz.");
  res.send()
})
router.post("/getotpsign", function(req, res, next){
  var number = req.body.number;
  var OTP = parseInt(Math.random()*100000).toString();
  sendOTP(number, OTP, "Hi Fuzzy!, {{otp}} is your Fuzz verification code. DO NOT SHARE this OTP.");
  res.send()
})
router.post("/verifyandcreate", function(req, res, next){
  var number = req.body.contact_number;
  var first_name = req.body.first_name;
  var otp = req.body.otp;
  var password = req.body.password;
  verifyOTP(number, otp, function(err, data){
    console.log(data);
    var status = {
      userExist: false,
      auth: false,
      created: 0
    }
    if(err){
      console.log(err);
      status.created = -1;
      res.send(status);
    }
    else if(data.type == "success"){
      status.created = 1;
      
      bcrypt.hash(req.body.password, salt, function(err, hash){
        bcrypt.hash(req.body.contact_number, salt, function(err, uid){
          var credentials = {
            uid:uid,
            contact_number: req.body.contact_number,
            delivered: [],
            defaults:{
              address:null
            },
            dob:null,
            email:null,
            favourites: [],
            first_name: req.body.first_name,
            mybag: [],
            mybag_items: [],
            orders: [],
            addresses: [],
            password: hash,
            pid: tokenGenerator(35),
            sessions:{},
            token: tokenGenerator(35),
            verified: false,
          }


          var params = {
            TableName: "Users",
            Key: {
              "uid": uid
            }
          }
          docClient.get(params, function(err, result){
            if(err){
              console.log("Unable to read item, ERROR JSON:", JSON.stringify(err, null, 2));
            } else {
              console.log(result);
              if(result.Item){
                status.userExist = true;
              } else {
                createUser(credentials)
                res.cookie('uid',decodeURIComponent(credentials.uid), { httpOnly: true });
                res.cookie('pid',decodeURIComponent(credentials.pid), { httpOnly: true });
                status.auth = true;
              
              }
              res.send(status);
            }
          })    
        })
      })
    } else {
      res.send(status);
    }
  })
})
router.post("/signinauth", function(req, res, next){
  var number = req.body.contact_number;
  var password = req.body.password;
  bcrypt.hash(password, salt, function(err, password){
    bcrypt.hash(number, salt, function(err, uid){
      var params = {
        TableName: "Users",
        ProjectionExpression: "uid, password, pid",
        Key: {
          uid: uid,
        }
      }
      docClient.get(params, function(err, result){
        var data = {
          auth: false
        };
        if(err){
          console.log("JSON Error:", JSON.stringify(err, null, 2));
        } else {
          if(result.Item){
            if(result.Item.password == password){
              res.cookie('uid',decodeURIComponent(uid), { httpOnly: true });
              res.cookie('pid',decodeURIComponent(result.Item.pid), { httpOnly: true });
              data.auth = true;
            }
          }
        }
        res.send(data);
      })
    })
  })
})
router.post("/verifyotp", function(req, res, next){
  var OTP = req.body.otp;
  var contact_number = req.body.contact_number;
  verifyOTP(contact_number, OTP, function(err, data){
    var render_data = {
      verified: 0
    }
    if(err){
      console.log(err);
      render_data.verified = -1;
    } else {
      if(data.type == "success"){
        render_data.verfied = 1;
      } 
    }
    res.send(render_data)
  })
})
router.post("/removeitem", function(req, res, next){
  var uid = req.cookies.uid;
  var params = {
    TableName: "Users",
    Key: {
      uid: uid,
    }
  }
  docClient.get(params, function(err, result){
    if(err){
      consle.log("JSON Error:", JSON.stringify(err, null, 2));
    } else {
      var user_details = result.Item;
      var index = user_details.mybag.indexOf(req.body.product_slug);
      user_details.mybag.splice(index, 1);
      user_details.mybag_items.splice(index, 1);

      var params = {
        TableName: "Users",
        Key: {
          uid: uid
        },
        UpdateExpression: "set mybag = :mybag, mybag_items = :mybag_items",
        ExpressionAttributeValues: {
          ":mybag": user_details.mybag,
          ":mybag_items": user_details.mybag_items
        }
      }
      docClient.update(params, function(err){
        if(err){
          console.log("JSON Error:", JSON.stringify(err, null, 2));
        } else {
          res.send(); 
        }
        
      })
    }
  })
})


router.post('/addaddress', function(req, res, next){
  var data = req.body;
  var status = {
    status: false,
    exist: false
  }
  var params = {
    TableName: "Users",
    Key: {
      uid: req.cookies.uid,
    }
  }
  docClient.get(params, function(err, result){
    if(err){
      console.log("JSON Error:", JSON.stringify(err, null, 2));
    } else {
      if(result.Item.addresses.indexOf(data.address_name) != -1){
        status.exist = true;
        res.send(status);
      } else {
        var params = {
          TableName: "Users",
          Key:{
            uid: decodeURIComponent(req.cookies.uid)
          },
          UpdateExpression: "set addresses = list_append(addresses,:address)",
          ExpressionAttributeValues: {
            ":address": [data]
          }
        }
        docClient.update(params, function(err, result){
          if(err){
            console.log("JSON Error:", JSON.stringify(err, null, 2));
            res.send(status)
          } else {
            status.status = true;
            res.send(status);
          }
        })
      }
    }
  })
})
router.post("/removeaddress", function(req, res, next){
  var add_name = req.body.add_name;
  var params = {
    TableName: "Users",
    Key: {
      uid: req.cookies.uid
    }
  }
  docClient.get(params, function(err, result){
    if(err){
      console.log("JSON Error:", JSON.stringify(err, null, 2));
    } else {
      if(result.Item){
        var addresses = result.Item.addresses;
        var defaults = result.Item.defaults;
        var index = -1;
        for(i in addresses){
          if(addresses[i].address_name == add_name){
            index = i;
            break;
          }
        }
        if(add_name == defaults.address){
          defaults.address = null;
        }
        addresses.splice(index, 1);
        var params = {
          TableName: "Users",
          Key: {
            uid: req.cookies.uid,
          },
          UpdateExpression: "set addresses = :add, defaults = :def",
          ExpressionAttributeValues: {
            ":add": addresses,
            ":def": defaults
          }
        }
        docClient.update(params, function(err, result){
          if(err){
            console.log("JSON Error:", JSON.stringify(err, null, 2));
          } else {
            res.send(); 
          }
        })
      } else {
        res.send("Blank Space")
      }
    }
  })
})

router.post('/setemail', function(req, res, next){
  var email = req.body.email;
  var data = {};
  var token = tokenGenerator(35);
  var params = {
    TableName: "Users",
    Key: {
      uid: req.cookies.uid
    },
    UpdateExpression: "set email = :email, #token = :token, #verified = :bool",
    ExpressionAttributeNames: {
      "#token": "token",
      "#verified": "verified",
    },
    ExpressionAttributeValues: {
      ":email":email,
      ":token": token,
      ":bool": false,
    }
  }
  docClient.update(params, function(err){
    if(err){
      console.log("JSON Error:", JSON.stringify(err, null, 2));
      data.status = false;

      res.send(data);
    } else {
      data.status = true;
      var web_add = "http://";
      if(req.get('X-Forwarded-Protocol')){
        web_add = "https://";
      }
      var url = web_add + req.get("host") + "/authenticate?token=" + token +
      "&uid=" + decodeURIComponent(req.cookies.uid);
      var msg = "Hi!\n" + 
      "Thank you to join us. Very warm welcome in Fuzz.\n\n" +
      "You can confirm you mail using the below link.\n\n" + url;
      mailer.sendFuzzMail(email, "Welcome in Fuzz", msg)
      res.send(data);
    }
  })
})
router.post('/addbirthday', function(req, res, next){
  var birthday = req.body.date;
  console.log(birthday);
  var params = {
    TableName: "Users",
    Key: {
      uid: req.cookies.uid,
    },
    UpdateExpression: "set dob = :dob",
    ExpressionAttributeValues: {
      ":dob":birthday
    }
  }
  docClient.update(params, function(err){
    var data = {};
    if(err){
      console.log("JSON Error:", JSON.stringify(err, null, 2));
      data.status = false;
      res.send(data);
    } else {
      data.status = true;
      res.send(data);
    }
  })
})
router.post('/addtolist', function(req, res, next) {
  /*
    Actions:
     0 = Nothing
    -1 = Removed
    +1 = Added
  */
  var params = {
    TableName: "Users",
    Key:{
      "uid": decodeURIComponent(req.cookies.uid)
    }
  }
  docClient.get(params, function(err, result){
    if(err){
      console.log("JSON Error:", JSON.stringify(err, null, 2));

    } else {
      if(result.Item){
        var user_details = result.Item;
        if(req.body.value == "false"){
          console.log("User")
          user_details.favourites.push(req.body.product_slug);
        } else {
          if((index = user_details.favourites.indexOf(req.body.product_slug)) != -1){
            user_details.favourites.splice(index,1);
          }
        }
        var params = {
          TableName: "Users",
          Key: {
            "uid": req.cookies.uid,
          },
          UpdateExpression: "set favourites = :fav",
          ExpressionAttributeValues: {
            ":fav": user_details.favourites
          }
        }
        docClient.update(params, function(err, result){
          if(err){
            console.log("JSON Error:",JSON.stringify(err, null, 2));
          }
        })

      }
    }
    var params = {
      TableName: "Product-Details",
      Key: {
        "product_slug": req.body.product_slug
      }
    }
    docClient.get(params, function(err, result){
      if(err){
        console.log("I'm In")
        console.log("JSON Error:", JSON.stringify(err, null, 2));
      } else {
        if(result.Item){
          var product = result.Item;
          if(req.body.value == "false"){
            console.log("Product");
            product.favourites_of.push(req.cookies.uid);
          } else {
            if((index = product.favourites_of.indexOf(req.cookies.uid)) != -1){
              product.favourites_of.splice(index, 1); 
            }           
          }
          var params = {
            TableName: "Product-Details",
            Key: {
              "product_slug": req.body.product_slug
            },
            UpdateExpression: "set favourites_of = :fav",
            ExpressionAttributeValues: {
              ":fav": product.favourites_of
            }
          }
          docClient.update(params, function(err, result){
            if(err){
              console.log("JSON Error:", JSON.stringify(err, null, 2));
            }
          })
        }
      }
    })
    var data = {};
    if(req.body.value == "false"){
      data.action = true
    } else {
      data.action = false
    }
    res.send(data)
  })
});

router.post("/addtomybag", function(req, res, next){
  var data = {
    status_user: false,
    status_bag: false
  }
  var product = JSON.parse(req.body.product);
  var uid = req.cookies.uid;
  var params = {
    TableName: "Product-Details",
    Key: {
      product_slug: req.body.product_slug
    }
  }
  docClient.get(params, function(err, result){
    if(err){
      console.log("JSON Error:", JSON.stringify(err, null, 2));
    } else {
      var product_details = result.Item;
      var order = {
        "product_title": product_details.product_title,
        "product_slug": req.body.product_slug,
        "img_src": product_details.img_src,
        "price": product_details.price_tag,
        "discount": product_details.discount,
        "size": product.size,
        "quantity": product.quantity
      }
      var params = {
        TableName: "Users",
        Key: {
          uid: uid,
        },
        UpdateExpression: "set mybag = list_append(mybag,:mybag), mybag_items = list_append(mybag_items,:mybag_items)",
        ExpressionAttributeValues: {
          ":mybag": [product_details.product_slug],
          ":mybag_items": [order]
        }
      }
      docClient.update(params, function(err, result){
        if(err){
          console.log("JSON Error:",JSON.stringify(err, null, 2));
        }
      })
    }
  })
  var status = {
    reached: true
  }
  res.send(status)
});

router.post("/removefromlist", function(req, res, next){
  var product_slug = req.body.product_slug;
  var params = {
    TableName: "Users",
    Key: {
      uid: req.cookies.uid,
    }
  }
  docClient.get(params, function(err, result){
    if(err){
      console.log("JSON Error:", JSON.stringify(err, null, 2));
    } else {
      if(result.Item){
        var favourites = result.Item.favourites;
        var index = favourites.indexOf(product_slug);
        favourites.splice(index, 1);
        var params = {
          TableName: "Users",
          UpdateExpression: "set favourites = :fav",
          ExpressionAttributeValues: {
            ":fav": favourites,
          },
          Key: {
            uid: req.cookies.uid
          }
        }
        docClient.update(params, function(err){
          if(err){
            console.log("JSON Error:", JSON.stringify(err, null, 2));
          }
        })
      }
      
    }
  })
  var params = {
    TableName: "Product-Details",
    Key: {
      product_slug: product_slug
    }
  }
  docClient.get(params, function(err, result){
    if(err){
      console.log("JSON Error:", JSON.stringify(err, null, 2));
    } else {
      if(result.Item){
        var fav = result.Item.favourites_of;
        var index = fav.indexOf(req.cookies.uid);
        fav.splice(index, 1);
        var params = {
          TableName: "Product-Details",
          Key: {
            product_slug: product_slug
          },
          UpdateExpression: "set favourites_of = :fav",
          ExpressionAttributeValues: {
            ":fav": fav,
          }
        }
        docClient.update(params, function(err){
          if(err){
            console.log("JSON Error:", JSON.stringify(err, null, 2));
          } else {
            res.send();
          }
        })
      }
    }
  })
})
router.post("/makeaddressdefault", function(req, res, next){
  var address_name = req.body.add_name;
  var params = {
    TableName: "Users",
    Key: {
      uid: req.cookies.uid
    },
    UpdateExpression: "set defaults.address = :address",
    ExpressionAttributeValues: {
      ":address": address_name
    }
  }
  docClient.update(params, function(err, result){
    if(err){
      console.log("JSON Error:", JSON.stringify(err, null, 2));
    } else {
      res.send();
    }
  })
})
router.post('/verify_and_checkout', function(req, res, next){
  const sendOtp = new SendOtp("215985Aycje66oc15afdfd00");

  sendOtp.verify(req.body.number, req.body.OTP, function(err, data, response){
    data.authorized = false;
    if(data.type == "success"){
      
      csrf_token = req.body.csrf_token;
      var uid = req.cookies.uid;
      var params = {
        TableName: "Users",
        Key: {
          uid: req.cookies.uid,
        }
      }
      docClient.get(params, function(err, result){
        if(err){
          console.log("JSON Error:", JSON.stringify(err, null, 2));
          res.send()
        } else {
          if(result.Item){
            var tokens = Object.values(result.Item.sessions);
            var keys = Object.keys(result.Item.sessions);
            if((index = tokens.indexOf(csrf_token)) != -1){
              data.authorized = true;
            } else {
              data.authorized = false
            }
            if(data.authorized){
              var user_details = result.Item;
              user_details.sessions = {};
              user_details.mybag = [];
              var address = req.body.address;
              for(i in user_details.addresses){
                if((temp = Object.values(user_details.addresses[i]).indexOf(address)) != -1){
                  address = user_details.addresses[i];
                  break;
                }
              }
              function getLength(something){
                return something.length;
              }
              
              user_details.mybag_items.forEach(function(item){
                var params = {
                  TableName: "Product-Details",
                  Key: {
                    product_slug: item.product_slug
                  },
                  UpdateExpression: "set purchased_by = list_append(purchased_by, :pur), purchase_count = purchase_count + :one",
                  ExpressionAttributeValues: {
                    ":pur": [req.cookies.uid],
                    ":one": 1
                  }
                }
                docClient.update(params, function(err){
                  if(err){
                    console.log("JSON Error:", JSON.stringify(err, null, 2));
                  }
                })
              })
              var msg_item = "";
              var len = getLength(user_details.mybag_items);
              for(i = 0; i < len;i++){
                msg_item = msg_item + "Product: " + user_details.mybag_items[0].product_title +
                "\nSlug: " + user_details.mybag_items[0].product_slug + 
                "\nPrice: " + user_details.mybag_items[0].price +
                "\nSize: " + user_details.mybag_items[0].size +
                "\nQuantity: " + user_details.mybag_items[0].quantity + "\n\n"

                user_details.orders.push(user_details.mybag_items.splice(0, 1)[0]);
              }
              var msg = "Hey Sweety, It's me Fuzzy!\n" + user_details.first_name +
              " with\nuid: " + user_details.uid + 
              "\nhave just ordered \n" + msg_item +
              "So Total added Rs." + req.body.total + " :)\n" +
              "AT ADDRESS as follows \n\n" + "Label: " + address.address_name + "\n" + 
              "Country: " + address.country + '\n' +
              "Full Name: " + address.full_name + '\n' +
              "Mobile Number: " + address.mobile_number + '\n' +
              "Pincode: " + address.pincode + '\n' + 
              "First Address: " + address.first_address + "\n" + 
              "Second Address: " + address.second_address + "\n" +
              "Landmark: " + address.landmark + '\n' + 
              "City: " + address.city + '\n' + 
              "State: " + address.state + '\n\n\n';


              mailer.sendFuzzMail("chaudharisanket2000@gmail.com", "New Order", msg);
              var params = {
                TableName: "Users",
                Key: {
                  uid: req.cookies.uid
                },
                UpdateExpression: "set orders = :orders, mybag = :mybag, mybag_items = :mybag_items, sessions = :sessions",
                ExpressionAttributeValues: {
                  ":orders": user_details.orders,
                  ":mybag": user_details.mybag,
                  ":mybag_items": user_details.mybag_items,
                  ":sessions": user_details.sessions
                }
              }
              docClient.update(params, function(err){
                if(err){
                  console.log("JSON Error:", JSON.stringify(err, null, 2)); 
                } else {
                  res.send(data);
                }                 
              })                
            }
          }
        }
              
      })
    } else {
      data.authorized = true;
      res.send(data);
      res.end();
    }
  })
})

module.exports = router;
