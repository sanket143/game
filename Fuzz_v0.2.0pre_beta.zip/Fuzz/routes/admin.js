var express = require('express');
var router = express.Router();
var path = require('path');
var multiparty = require('multiparty');
var fs = require("fs");
var AWS = require("aws-sdk");



/* WARNING: DynamoDB Config */
AWS.config.update({
  region: "ap-south-1",
  endpoint: "https://dynamodb.ap-south-1.amazonaws.com"
});
var docClient = new AWS.DynamoDB.DocumentClient();


function slugify(input){
  var slug = input.toLowerCase();
  slug = slug.replace(/ /g,"_");
  slug = slug.replace(/-/,"_");
  return slug;
}

router.get("/", function(req, res, next){

  if(true){
    res.render("admin");
  } else {
    var err = {
      message: "Not Found",
      error: {
        status: 404,
      }
    }
    res.status(404);
    res.render("error", err)
  }
})

router.post('/upload', function(req, res, next){
  var form = new multiparty.Form();
  var uploadParams = {Bucket: "fuzz143", Key: '', Body: ''};
  form.parse(req, function(err, fields, files) {
    var date_token = Date.now();
    var product_slug = slugify(fields.product_title[0]);
    product_slug += "_" + date_token;
    var product_img = files.product_img[0];
    var available_sizes = fields.available_sizes[0].toUpperCase().split(/[\s,]+/);
    var keywords = fields.keywords[0].toLowerCase().split(/[\s,]+/);
    var colors = [
      (fields.white ? fields.white[0] : null),
      (fields.black ? fields.black[0] : null),
      (fields.red ? fields.red[0] : null),
      (fields.green ? fields.green[0] : null),
      (fields.multi ? fields.multi[0] : null)
    ]
    colors = colors.filter(Boolean);
    var data = {};
    data.product_title = fields.product_title[0];
    data.product_slug = product_slug;
    data.img_src = product_slug + path.extname(product_img.originalFilename);
    data.available_sizes = available_sizes;
    data.tag = {
      "neck": fields.neck[0],
      "wear": fields.wear[0],
      "quality": fields.quality[0],
      "cloth_type": fields.cloth_type[0],
      "theme": fields.theme[0],
      "colors": colors
    }
    data.price_tag = fields.price_tag[0];
    data.discount = fields.discount[0];
    data.reviews = [];
    data.purchase_count = 0;
    data.views = 0;
    data.keywords = keywords;
    data.favourites_of = [];
    data.purchased_by = [];
    data.print_type = fields.print_type[0];
    data.print_by = fields.print_by[0];
    data.cloth_by = fields.cloth_by[0];
    data.cost_price = fields.cost_price[0];
    var params = {
      TableName: "Product-Details",
      Item:data
    }
    docClient.put(params, function(err, data){
      if(err){
        console.log(err);

      }
    })

    /* WARNING: S3 Config */
    AWS.config.update({
      region: "ap-south-1",
      endpoint: null   
    });
    var s3 = new AWS.S3({apiVersion: '2006-03-01'});
    
    var fileStream = fs.createReadStream(product_img.path);
    fileStream.on("error", function(err){
      console.log("File Error:", err);
    })
    uploadParams.Body = fileStream;
    uploadParams.Key = "product_images/"+data.img_src;
    
    s3.upload(uploadParams, function(err, data){
      if(err){
        console.log("Error",err);
      } else {
        console.log("Upload Success.", data.location);
      }
    })
    res.redirect("/admin");
    });
});
module.exports = router;