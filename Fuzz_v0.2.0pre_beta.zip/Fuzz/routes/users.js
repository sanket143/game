var express = require('express');
var router = express.Router();
var userAuthentication = require('./modules/UserAuth').userAuthentication;

var AWS = require("aws-sdk");
AWS.config.update({
  region: "ap-south-1",
  endpoint: "https://dynamodb.ap-south-1.amazonaws.com"
});
var docClient = new AWS.DynamoDB.DocumentClient();



// Token Generator
function tokenGenerator(len) {
  charSet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var token = '';
  for (var i = 0; i < len; i++) {
    var randomPoz = Math.floor(Math.random() * charSet.length);
    token += charSet.substring(randomPoz,randomPoz+1);
  }
  return token;
}


router.get("/orders", function(req, res, next){
  var data;
  userAuthentication(req, res, function(req, res, data){
    if(data.auth){
      res.render("orders", data);
    } else {
      res.redirect("/");
    }
  })
})




router.get('/settings', function(req, res, next){
  res.redirect("/user/settings/addresses")
})

router.get('/settings/:option', function(req, res, next) {
  var options = ["addresses", "profile"];
  userAuthentication(req, res, function(req, res, data){
    if(data.auth){
      if(options.indexOf(req.params.option) != -1){
        data.option = req.params.option
        res.render("settings", data);
      } else {
        res.redirect("/user/settings/addresses");
      }
    }
  })  
});



router.post('/settings/', function(req, res, next){
  var options = ["addresses", "profile"];
  var data = {
    status: false
  }
  userAuthentication(req, res, function(req, res, data){
    if(data.auth){
      if(options.indexOf(req.body.option) != -1){
        data.option = req.body.option
        res.render("templates/settings/" + data.option, data);
      } else {
        res.send(data);
      }
    }
  })  
})

// Favourites

router.get("/mydreamlist", function(req, res, next){
  var data;
  if(!req.cookies.pid){
    res.redirect('/');
  } else {
    userAuthentication(req, res, function(req, res, data){
      if(data.auth){
        var params = {
          TableName: "Product-Details"
        }
        docClient.scan(params, function(err, result){
          if(err){
            console.log("JSON Error:", JSON.stringify(err, null, 2));
          } else {
            var fav = [];
            result.Items.forEach(function(product){
              if(data.user_details.favourites.indexOf(product.product_slug) != -1){
                fav.push(product);
              }
            })
            data.fav_list = fav;
            res.render("dreamlist", data);
          }
        })
      } else {
        res.redirect("/");
      }
    })      
  }
});



router.get("/mybag", function(req, res, next){
  userAuthentication(req, res, function(req, res, data){
    var csrf_token = tokenGenerator(35);
    if(data.auth){
      var sessions = data.user_details.sessions;
      data.csrf_token = csrf_token;
      sessions[Date.now()] = csrf_token;
      var params = {
        TableName: "Users",
        Key: {
          uid: req.cookies.uid,
        },
        UpdateExpression: "set sessions = :session",
        ExpressionAttributeValues: {
          ":session": sessions
        }
      }
      docClient.update(params, function(err){
        if(err){
          console.log("JSON Error:", JSON.stringify(err, null, 2));
        }
      })
      res.render("mybag", data);
    } else {
      res.redirect("/")
    }
  })

})

module.exports = router;
