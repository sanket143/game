var express = require('express');
var router = express.Router();
var userAuthentication = require('./modules/UserAuth').userAuthentication;

var AWS = require("aws-sdk");
AWS.config.update({
  region: "ap-south-1",
  endpoint: "https://dynamodb.ap-south-1.amazonaws.com"
});
var docClient = new AWS.DynamoDB.DocumentClient();




router.get("/", function(req, res, next){
  if(!req.query.q || !req.query.t){
    res.redirect("/");
  } else {
    var t = req.query.t;
    var q = req.query.q;
    userAuthentication(req, res, function(req, res, data){
      var params = {
        TableName: "Product-Details",
        ProjectionExpression: "product_title, product_slug, img_src, price_tag, discount, tag",
        
      }
      docClient.scan(params, function(err, result){
        if(err){
          console.log("JSON Error:", JSON.stringify(err, null, 2));
        } else {
          var products = [];
          result.Items.forEach(function(product){
            if(t != "color" && product.tag[t] == q){
              products.push(product);
            }
            else if(product.tag[t].indexOf(q) != -1){
              products.push(product);
            }
          })
          data.product_details = products;
          res.render("index", data);
        }
      })
    })
  }
})

router.post("/", function(req, res, next){
  if(!req.body.q || !req.body.t){
    res.redirect("/");
  } else {
    var t = req.body.t;
    var q = req.body.q;
    var data = {};
    var params = {
      TableName: "Product-Details",
      ProjectionExpression: "product_title, product_slug, img_src, price_tag, discount, tag",
      
    }
    docClient.scan(params, function(err, result){
      if(err){
        console.log("JSON Error:", JSON.stringify(err, null, 2));
      } else {
        var products = [];
        result.Items.forEach(function(product){
          if(t != "color" && product.tag[t] == q){
            products.push(product);
          }
          else if(product.tag[t].indexOf(q) != -1){
            products.push(product);
          }
        })
        data.product_details = products;
        res.render("templates/show_products", data);
      }
    })
  }
})



router.get('/price', function(req, res, next){
  var price = req.query.lim;
  userAuthentication (req, res, function(request, response, data){
    var params = {
      TableName: "Product-Details",
      ProjectionExpression: "product_title, product_slug, img_src, price_tag, discount, tag",
      
    }
    docClient.scan(params, function(err, result){
      if(err){
        console.log("JSON Error:", JSON.stringify(err, null, 2));
      } else {
        var products = [];
        result.Items.forEach(function(product){
          if(parseInt(product.price_tag - product.price_tag * product.discount / 100)-1 <= price){
            products.push(product);
          }
        })
        data.product_details = products;
        data.price_limit = price;
        res.render("index", data);
      }
    })
  })
})


router.post('/price', function(req, res, next){
  var price = req.body.lim;
  var data = {};
  var params = {
    TableName: "Product-Details",
    ProjectionExpression: "product_title, product_slug, img_src, price_tag, discount, tag",
    
  }
  docClient.scan(params, function(err, result){
    if(err){
      console.log("JSON Error:", JSON.stringify(err, null, 2));
    } else {
      var products = [];
      result.Items.forEach(function(product){
        if(parseInt(product.price_tag - product.price_tag * product.discount / 100)-1 <= price){
          products.push(product);
        }
      })
      data.product_details = products;
      res.render("templates/show_products", data);
    }
  })

})

module.exports = router;