function showError(msg){
  $(".pop-error").html(msg);
  $(".pop-error").fadeIn("fast");
  var error_timeout = setTimeout(function(){
    $(".pop-error").fadeOut("fast");
  },10000)
}

$(document).ready(function(){
  $("#register_form").on("submit",function(eve){
    eve.preventDefault();
    var psw1 = $("input[name=password1]").val();
    var psw2 = $("input[name=password2]").val();
    $(".loading-bar").show();
    if(psw1 == psw2){
      if(psw1.length < 8){
        showError("Password length must be greater than 7.")
      } else {
        $.ajax({
          type:'post',
          url:'/newuser',
          data:{
            firstName: $("input[name=firstName]").val(),
            contactNumber: $("input[name=contact_number]").val(),
            dob: $("input[name=dob]").val(),
            password: psw2,
          },
          success:function(data){
            $(".loading-bar").hide();
            if(data.userExist){
              if(data.email){
                showError("User with that Email Address already exist.")  
              }
            }
            else{
              var msg = "Your account is successfully created, " +
              " please check you mail box for confirmation mail";
              showError(msg);
              //window.location = window.location.origin;
            }
          },
          error:function(){
            $(".loading-bar").hide();
            console.log("Error Occured")
          }
        })
      }
    } else {
      showError("Password didn't matched !")
    }   
  })

  $("#sign_form").on("submit", function(eve){
    showError("Please Wait...");
    eve.preventDefault();
    $(".loading-bar").show();
    $.ajax({
      type:"post",
      url: "/signinauth",
      data: {
        "email":$("input[name=email_sign]").val(),
        "password": $("input[name=password_sign]").val(),
      },
      success: function(data){
        $(".loading-bar").hide();
        if(data.auth){
          //window.location = window.location.origin;
        } else {
          showError("Invalid Email or Password.");
        }
      },
      error: function(){
        $(".loading-bar").hide();
        console.log("Error Occured");
      }
    })
  })
  $("#confirm_otp").click(function(){
    var OTP = $(".verify-otp-pop").val();
    $.ajax({
      type:"POST",
      url: "/action/verifyotp",
      data: {
        otp: OTP,
        contact_number: $(".contact_number").val(),
      },
      success: function(data){
        console.log(data);
      },
      error: function(){
        console.log("Error Occured");
      }
    })
  })

  $("#have-account").on("click", function(){
    $(".register").hide();
    $(".sign").show();
  })
  $("#no-account").on("click", function(){
    $(".sign").hide();
    $(".register").show();
  })

  $(".pop-error").on("click" , function(){
    $(this).fadeOut("fast");
  })
})

