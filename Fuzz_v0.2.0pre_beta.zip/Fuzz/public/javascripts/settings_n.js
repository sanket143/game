$(".menu-item").click(function(){
  var option = $(this).attr("value");
  $(".menu-item").css({
    "font-weight": 100,
    "border-left": "1px solid #e1e4e8"
  })
  $(this).css({
    "font-weight": "bold",
    "border-left": "1px solid #0097D3"
  })
  $.ajax({
    type: "post",
    url: "/user/settings/",
    data: {
      option: option
    },
    success: function(data){
      if(data.status === false){
        showError("Error Occured.");
      } else {
        $(".content").html(data);
        var state = {
          "name": option
        }
        option[0] = option[0].toUpperCase();
        changeUrl(state, option, "/user/settings/" + option)
      }

    },
    error: function(){
      showError("Check your Internet Connection and Try Again!");
    }
  })
})