var size_selected = false;
$(document).ready(function(){
  $(".size-button").on("click",function(){
    $(".size-button").css({"background-color":"white", "color":"#0097D3"});
    $(this).css({"background-color":"#0097D3","color":"white"});
    size_selected = true;
  })
  $(".size-button").hover(function(e){
    if(!size_selected){
      $(this).css({
        "background-color":(e.type === "mouseenter" ? "#0097D3" : "white"),
        "color":(e.type === "mouseenter" ? "white" : "#0097D3")
      })
    }
  })
  $("#quantity").on('keypress',function(e){
    e.preventDefault();
  })
})
$('.image-view')
// tile mouse actions
.on('mouseover', function(){
  $(this).children('.product-thumbnail-big').css({'transform': 'scale(2.4)'});
})
.on('mouseout', function(){
  $(this).children('.product-thumbnail-big').css({'transform': 'scale(1)'});
})
.on('mousemove', function(e){
  $(this).children('.product-thumbnail-big').css({'transform-origin': ((e.pageX - $(this).offset().left) / $(this).width()) * 100 + '% ' + ((e.pageY - $(this).offset().top) / $(this).height()) * 100 +'%'});
})
